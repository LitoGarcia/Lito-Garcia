import React from "react";
import { View, Text, StyleSheet, ScrollView } from "react-native";

export default function App() {
  return (
    <ScrollView style={styles.container}>
      {/* Screen 1 */}
      <Text style={styles.title}>iPhone 16 Pro Max - 1</Text>
      <View style={styles.screen}>
        {/* Personal Info Box */}
        <View style={[styles.infoBox, styles.green]}>
          <Text style={styles.infoTitle}>Personal Information</Text>
          <Text style={styles.infoText}>Name: Lito Garcia JR</Text>
          <Text style={styles.infoText}>Age: 25</Text>
          <Text style={styles.infoText}>Status: Student of USTP CDOC</Text>
        </View>

        {/* Green Bar */}
        <View style={[styles.bar, styles.blue]}>
          <Text>PERSONAL INFORMATION</Text>
        </View>

        {/* Two Column Row */}
        <View style={styles.row}>
          <View style={[styles.colBox, styles.green]}>
            <Text>MALE</Text>
          </View>
          <View style={[styles.colBox, styles.green]}>
            <Text>09709635583</Text>
          </View>
        </View>

        {/* Big Orange Section */}
        <View style={[styles.orangeSection, styles.blue]}>
          <View style={[styles.bar, styles.green]}>
            <Text>PARENT NAME:</Text>
          </View>
          <View style={styles.row}>
            <View style={[styles.smallBox, styles.green]}>
              <Text>REYNELDA GARCIA</Text>
            </View>
            <View style={[styles.smallBox, styles.green]}>
              <Text>LITO GARCIA SR</Text>
            </View>
          </View>
          <View style={[styles.bar, styles.green]}>
            <Text>BSIT 3R7</Text>
          </View>
        </View>

        {/* Bottom Purple */}
        <View style={[styles.bar, styles.purple]}>
          <Text>KAPOY NA</Text>
        </View>
      </View>

      {/* Screen 2 */}
      <Text style={styles.title}>iPhone 16 Pro Max - 2</Text>
      <View style={styles.screen}>
        {/* Green Bar */}
        <View style={[styles.bar, styles.purple]}>
          <Text>BROTHERS AND SISTERS NAME: </Text>
        </View>

        {/* Two Rows of Pink Boxes */}
        <View style={styles.row}>
          <View style={[styles.colBox, styles.orange]}>
            <Text>MARVIN GARCIA</Text>
          </View>
          <View style={[styles.colBox, styles.orange]}>
            <Text>KARL KHEVEN GARCIA</Text>
          </View>
        </View>

        <View style={styles.row}>
          <View style={[styles.colBox, styles.purple]}>
            <Text>REYNIEL GARCIA</Text>
          </View>
          <View style={[styles.colBox, styles.purple]}>
            <Text>CHARINA GARCIA</Text>
          </View>
        </View>

        {/* Green Bar */}
        <View style={[styles.bar, styles.blue]}>
          <Text>BOY:3 GIRL: 1 </Text>
        </View>

        {/* Orange Bar */}
        <View style={[styles.bar, styles.orange]}>
          <Text>AGE:</Text>
        </View>

        {/* Row of Small Blue Boxes */}
        <View style={styles.row}>
          <View style={[styles.smallBox, styles.green]}>
            <Text>24</Text>
          </View>
          <View style={[styles.smallBox, styles.blue]}>
            <Text>26</Text>
          </View>
          <View style={[styles.smallBox, styles.purple]}>
            <Text>28</Text>
          </View>
          <View style={[styles.smallBox, styles.orange]}>
            <Text>21</Text>
          </View>
        </View>

        {/* Big Green */}
        <View style={[styles.bigBox, styles.green]}>
          <Text>BOUTAN KONG MATULOG</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#eee",
    padding: 10,
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginVertical: 10,
  },
  screen: {
    backgroundColor: "#fff",
    padding: 10,
    marginBottom: 20,
    borderRadius: 10,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 5,
  },
  box: {
    flex: 1,
    height: 40,
    marginHorizontal: 5,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 5,
  },
  bar: {
    height: 50,
    marginVertical: 5,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  colBox: {
    flex: 1,
    height: 80,
    margin: 5,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  smallBox: {
    flex: 1,
    height: 40,
    margin: 5,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  orangeSection: {
    padding: 10,
    borderRadius: 5,
    marginVertical: 5,
  },
  bigBox: {
    height: 100,
    marginVertical: 10,
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  // New Personal Info Box
  infoBox: {
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  infoTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 5,
    color: "#fff",
  },
  infoText: {
    fontSize: 12,
    color: "#fff",
  },
  // Colors
  purple: { backgroundColor: "#7e57c2" },
  green: { backgroundColor: "#4caf50" },
  pink: { backgroundColor: "#f48fb1" },
  cyan: { backgroundColor: "#4dd0e1" },
  orange: { backgroundColor: "#fb8c00" },
  blue: { backgroundColor: "#039be5" },
});


